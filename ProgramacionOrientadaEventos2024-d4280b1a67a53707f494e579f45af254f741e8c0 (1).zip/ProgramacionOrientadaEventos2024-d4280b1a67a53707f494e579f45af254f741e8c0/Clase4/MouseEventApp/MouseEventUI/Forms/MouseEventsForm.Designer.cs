﻿namespace MouseEventUI.Forms
{
    partial class MouseEventsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            testingButton = new Button();
            messageLabel = new Label();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(108, 27);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(505, 38);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Eventos Mouse Hover Y Mouse Leave";
            // 
            // testingButton
            // 
            testingButton.Location = new Point(239, 114);
            testingButton.Name = "testingButton";
            testingButton.Size = new Size(217, 71);
            testingButton.TabIndex = 1;
            testingButton.Text = "Eventos";
            testingButton.UseVisualStyleBackColor = true;
            testingButton.MouseLeave += testingButton_MouseLeave;
            testingButton.MouseHover += testingButton_MouseHover;
            // 
            // messageLabel
            // 
            messageLabel.AutoSize = true;
            messageLabel.Location = new Point(108, 295);
            messageLabel.Name = "messageLabel";
            messageLabel.Size = new Size(0, 38);
            messageLabel.TabIndex = 2;
            // 
            // MouseEventsForm
            // 
            AutoScaleDimensions = new SizeF(16F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(694, 436);
            Controls.Add(messageLabel);
            Controls.Add(testingButton);
            Controls.Add(titleLabel);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(6);
            Name = "MouseEventsForm";
            Text = "MouseEventsForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private Button testingButton;
        private Label messageLabel;
    }
}