﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MouseEventUI.Forms
{
    public partial class MouseEventsForm : Form
    {
        public MouseEventsForm()
        {
            InitializeComponent();
        }

        private void testingButton_MouseHover(object sender, EventArgs e)
        {
            messageLabel.Text = "Evento Mouse Hover Activado";
            testingButton.BackColor = Color.Red;
            //testingButton.Height = 100;
            //testingButton.Width = 100;
        }

        private void testingButton_MouseLeave(object sender, EventArgs e)
        {
            messageLabel.Text = "Evento Mouse Leave Activado";
            testingButton.BackColor = Color.Blue;
            //testingButton.Height = 200;
            //testingButton.Width = 200;
        }
    }
}
