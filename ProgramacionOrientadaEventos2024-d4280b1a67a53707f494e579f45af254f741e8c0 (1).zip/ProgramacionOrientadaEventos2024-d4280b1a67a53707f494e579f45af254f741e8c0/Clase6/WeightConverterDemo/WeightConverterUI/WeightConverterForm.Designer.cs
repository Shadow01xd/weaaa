﻿namespace WeightConverterUI
{
    partial class WeightConverterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            unitsLabel = new Label();
            unitsComboBox = new ComboBox();
            quantityLabel = new Label();
            quantityTextBox = new TextBox();
            convertUnitsButton = new Button();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleLabel.Location = new Point(107, 29);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(266, 38);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Convertir unidades";
            // 
            // unitsLabel
            // 
            unitsLabel.AutoSize = true;
            unitsLabel.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            unitsLabel.Location = new Point(60, 90);
            unitsLabel.Name = "unitsLabel";
            unitsLabel.Size = new Size(127, 31);
            unitsLabel.TabIndex = 1;
            unitsLabel.Text = "Seleccione";
            // 
            // unitsComboBox
            // 
            unitsComboBox.FormattingEnabled = true;
            unitsComboBox.Location = new Point(66, 136);
            unitsComboBox.Name = "unitsComboBox";
            unitsComboBox.Size = new Size(362, 28);
            unitsComboBox.TabIndex = 2;
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            quantityLabel.Location = new Point(66, 203);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new Size(110, 31);
            quantityLabel.TabIndex = 3;
            quantityLabel.Text = "Cantidad";
            // 
            // quantityTextBox
            // 
            quantityTextBox.BorderStyle = BorderStyle.FixedSingle;
            quantityTextBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            quantityTextBox.Location = new Point(69, 245);
            quantityTextBox.Name = "quantityTextBox";
            quantityTextBox.Size = new Size(359, 34);
            quantityTextBox.TabIndex = 4;
            // 
            // convertUnitsButton
            // 
            convertUnitsButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            convertUnitsButton.Location = new Point(86, 302);
            convertUnitsButton.Name = "convertUnitsButton";
            convertUnitsButton.Size = new Size(321, 39);
            convertUnitsButton.TabIndex = 5;
            convertUnitsButton.Text = "Convertir";
            convertUnitsButton.UseVisualStyleBackColor = true;
            convertUnitsButton.Click += convertUnitsButton_Click;
            // 
            // WeightConverterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(489, 368);
            Controls.Add(convertUnitsButton);
            Controls.Add(quantityTextBox);
            Controls.Add(quantityLabel);
            Controls.Add(unitsComboBox);
            Controls.Add(unitsLabel);
            Controls.Add(titleLabel);
            Name = "WeightConverterForm";
            Text = "WeightConverterForm";
            Load += WeightConverterForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private Label unitsLabel;
        private ComboBox unitsComboBox;
        private Label quantityLabel;
        private TextBox quantityTextBox;
        private Button convertUnitsButton;
    }
}