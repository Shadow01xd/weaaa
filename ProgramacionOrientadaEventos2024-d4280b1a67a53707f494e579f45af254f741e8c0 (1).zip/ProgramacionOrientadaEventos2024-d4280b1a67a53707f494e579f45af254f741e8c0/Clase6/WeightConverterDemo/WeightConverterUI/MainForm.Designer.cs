﻿namespace WeightConverterUI
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            weightConverterButton = new Button();
            distanceConverterButton = new Button();
            volumeConverterButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(135, 40);
            label1.Name = "label1";
            label1.Size = new Size(318, 38);
            label1.TabIndex = 0;
            label1.Text = "Conversor de Unidades";
            // 
            // weightConverterButton
            // 
            weightConverterButton.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            weightConverterButton.Location = new Point(53, 125);
            weightConverterButton.Name = "weightConverterButton";
            weightConverterButton.Size = new Size(139, 81);
            weightConverterButton.TabIndex = 1;
            weightConverterButton.Text = "Unidades de Peso";
            weightConverterButton.UseVisualStyleBackColor = true;
            weightConverterButton.Click += weightConverterButton_Click;
            // 
            // distanceConverterButton
            // 
            distanceConverterButton.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            distanceConverterButton.Location = new Point(235, 125);
            distanceConverterButton.Name = "distanceConverterButton";
            distanceConverterButton.Size = new Size(139, 81);
            distanceConverterButton.TabIndex = 2;
            distanceConverterButton.Text = "Unidades Distancia";
            distanceConverterButton.UseVisualStyleBackColor = true;
            // 
            // volumeConverterButton
            // 
            volumeConverterButton.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            volumeConverterButton.Location = new Point(411, 125);
            volumeConverterButton.Name = "volumeConverterButton";
            volumeConverterButton.Size = new Size(139, 81);
            volumeConverterButton.TabIndex = 3;
            volumeConverterButton.Text = "Unidades Volumen";
            volumeConverterButton.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(619, 257);
            Controls.Add(volumeConverterButton);
            Controls.Add(distanceConverterButton);
            Controls.Add(weightConverterButton);
            Controls.Add(label1);
            Name = "MainForm";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button weightConverterButton;
        private Button distanceConverterButton;
        private Button volumeConverterButton;
    }
}
