namespace WeightConverterUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void weightConverterButton_Click(object sender, EventArgs e)
        {
            WeightConverterForm weightConverterForm = new WeightConverterForm();
            weightConverterForm.ShowDialog();
        }
    }
}
