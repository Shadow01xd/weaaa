﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeightConverterUI
{
    public partial class WeightConverterForm : Form
    {
        public WeightConverterForm()
        {
            InitializeComponent();
        }

        private void WeightConverterForm_Load(object sender, EventArgs e)
        {
            unitsComboBox.Items.AddRange([
                "Libras a Kilogramos",
                "Gramos a Libras"
            ]);
        }

        private void convertUnitsButton_Click(object sender, EventArgs e)
        {
            if(!decimal.TryParse(quantityTextBox.Text, out decimal weight))
            {
                MessageBox.Show("Debe ingresar una cantidad numerica");
                return;
            }

            switch (unitsComboBox.SelectedItem.ToString())
            {
                case "Libras a Kilogramos":
                    decimal kilograms = weight * 0.453592m;
                    MessageBox.Show($"{weight} libras equivale a {kilograms} kilos");
                    break;
                case "Gramos a Libras":
                    decimal pounds = weight * 0.0022m;
                    MessageBox.Show($"{weight} gramos equivale a {pounds} libras");
                    break;
                default:
                    MessageBox.Show("No se selecciono una opcion valida");
                    break;
            }

        }
    }
}
