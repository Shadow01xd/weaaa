namespace Clase6_ExcepctionsUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calculateDivideButton_Click(object sender, EventArgs e)
        {
            try
            {
                decimal firstNumber = Convert.ToDecimal(firstNumberTextBox.Text);
                decimal secondNumber = Convert.ToDecimal(secondNumberTextBox.Text);

                decimal total = firstNumber / secondNumber;

                MessageBox.Show($"El resultado de la divisi�n es {total}");
            }
            catch (DivideByZeroException ex)
            {
                MessageBox.Show(
                    "No se puede dividir entre cero", 
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch(FormatException ex)
            {
                MessageBox.Show(
                   "Ingrese solamente numeros",
                   "Error",
                   MessageBoxButtons.OK,
                   MessageBoxIcon.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
