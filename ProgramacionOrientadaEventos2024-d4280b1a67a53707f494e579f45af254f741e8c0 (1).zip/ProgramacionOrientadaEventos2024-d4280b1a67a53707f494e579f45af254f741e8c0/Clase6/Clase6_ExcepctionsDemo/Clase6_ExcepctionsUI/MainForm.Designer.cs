﻿namespace Clase6_ExcepctionsUI
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            firstNumberLabel = new Label();
            firstNumberTextBox = new TextBox();
            secondNumberTextBox = new TextBox();
            secondNumberLabel = new Label();
            calculateDivideButton = new Button();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleLabel.Location = new Point(72, 27);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(340, 38);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "División de dos números";
            // 
            // firstNumberLabel
            // 
            firstNumberLabel.AutoSize = true;
            firstNumberLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            firstNumberLabel.Location = new Point(72, 103);
            firstNumberLabel.Name = "firstNumberLabel";
            firstNumberLabel.Size = new Size(216, 38);
            firstNumberLabel.TabIndex = 1;
            firstNumberLabel.Text = "Primer número";
            // 
            // firstNumberTextBox
            // 
            firstNumberTextBox.BorderStyle = BorderStyle.FixedSingle;
            firstNumberTextBox.Location = new Point(79, 157);
            firstNumberTextBox.Name = "firstNumberTextBox";
            firstNumberTextBox.Size = new Size(323, 27);
            firstNumberTextBox.TabIndex = 2;
            // 
            // secondNumberTextBox
            // 
            secondNumberTextBox.BorderStyle = BorderStyle.FixedSingle;
            secondNumberTextBox.Location = new Point(79, 271);
            secondNumberTextBox.Name = "secondNumberTextBox";
            secondNumberTextBox.Size = new Size(323, 27);
            secondNumberTextBox.TabIndex = 4;
            // 
            // secondNumberLabel
            // 
            secondNumberLabel.AutoSize = true;
            secondNumberLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            secondNumberLabel.Location = new Point(72, 217);
            secondNumberLabel.Name = "secondNumberLabel";
            secondNumberLabel.Size = new Size(244, 38);
            secondNumberLabel.TabIndex = 3;
            secondNumberLabel.Text = "Segundo número";
            // 
            // calculateDivideButton
            // 
            calculateDivideButton.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calculateDivideButton.Location = new Point(82, 331);
            calculateDivideButton.Name = "calculateDivideButton";
            calculateDivideButton.Size = new Size(320, 46);
            calculateDivideButton.TabIndex = 5;
            calculateDivideButton.Text = "Dividir";
            calculateDivideButton.UseVisualStyleBackColor = true;
            calculateDivideButton.Click += calculateDivideButton_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(478, 404);
            Controls.Add(calculateDivideButton);
            Controls.Add(secondNumberTextBox);
            Controls.Add(secondNumberLabel);
            Controls.Add(firstNumberTextBox);
            Controls.Add(firstNumberLabel);
            Controls.Add(titleLabel);
            Name = "MainForm";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private Label firstNumberLabel;
        private TextBox firstNumberTextBox;
        private TextBox secondNumberTextBox;
        private Label secondNumberLabel;
        private Button calculateDivideButton;
    }
}
