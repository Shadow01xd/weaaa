﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountLibrary
{
    public class BankAccount : IBankAccount
    {
        public string AccountOwner { get; set; }

        public string AccountNumber { get; private set; }

        public decimal Balance { get; private set; }

        public BankAccount(
            string accountNumber, 
            string accountOwner,
            decimal initialBalance)
        {
            AccountNumber = accountNumber;
            AccountOwner = accountOwner;
            Balance = initialBalance;

        }
        public decimal GetBalance()
        {
            return Balance;
        }

        public void MakeDeposit(decimal amount)
        {
            Balance += amount;
        }

        public void MakeWithdraw(decimal amount)
        {
            if ((Balance - amount) < 0)
                throw new InvalidOperationException("No hay fondos suficientes");

            if (amount < 0)
                throw new InvalidOperationException("La cantidad debe ser mayor a cero");

            Balance -= amount;

        }
    }
}
