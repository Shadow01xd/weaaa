﻿namespace BankAccountUI
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            balanceGroupBox = new GroupBox();
            getBalanceButton = new Button();
            depositGroupBox = new GroupBox();
            depositTextBox = new TextBox();
            saveDepositButton = new Button();
            balanceGroupBox.SuspendLayout();
            depositGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(158, 30);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(437, 38);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Administracion Cuenta Bancaria";
            // 
            // balanceGroupBox
            // 
            balanceGroupBox.Controls.Add(getBalanceButton);
            balanceGroupBox.Location = new Point(39, 141);
            balanceGroupBox.Name = "balanceGroupBox";
            balanceGroupBox.Size = new Size(335, 247);
            balanceGroupBox.TabIndex = 1;
            balanceGroupBox.TabStop = false;
            balanceGroupBox.Text = "Ver Saldo";
            // 
            // getBalanceButton
            // 
            getBalanceButton.Location = new Point(59, 86);
            getBalanceButton.Name = "getBalanceButton";
            getBalanceButton.Size = new Size(198, 80);
            getBalanceButton.TabIndex = 0;
            getBalanceButton.Text = "Ver Saldo";
            getBalanceButton.UseVisualStyleBackColor = true;
            getBalanceButton.Click += getBalanceButton_Click;
            // 
            // depositGroupBox
            // 
            depositGroupBox.Controls.Add(depositTextBox);
            depositGroupBox.Controls.Add(saveDepositButton);
            depositGroupBox.Location = new Point(428, 141);
            depositGroupBox.Name = "depositGroupBox";
            depositGroupBox.Size = new Size(335, 247);
            depositGroupBox.TabIndex = 2;
            depositGroupBox.TabStop = false;
            depositGroupBox.Text = "Depositos";
            // 
            // depositTextBox
            // 
            depositTextBox.BorderStyle = BorderStyle.FixedSingle;
            depositTextBox.Location = new Point(54, 68);
            depositTextBox.Name = "depositTextBox";
            depositTextBox.Size = new Size(233, 43);
            depositTextBox.TabIndex = 1;
            // 
            // saveDepositButton
            // 
            saveDepositButton.Location = new Point(62, 135);
            saveDepositButton.Name = "saveDepositButton";
            saveDepositButton.Size = new Size(198, 86);
            saveDepositButton.TabIndex = 0;
            saveDepositButton.Text = "Hacer Deposito";
            saveDepositButton.UseVisualStyleBackColor = true;
            saveDepositButton.Click += saveDepositButton_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(16F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(861, 515);
            Controls.Add(depositGroupBox);
            Controls.Add(balanceGroupBox);
            Controls.Add(titleLabel);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(6);
            Name = "MainForm";
            Text = "Form1";
            balanceGroupBox.ResumeLayout(false);
            depositGroupBox.ResumeLayout(false);
            depositGroupBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private GroupBox balanceGroupBox;
        private Button getBalanceButton;
        private GroupBox depositGroupBox;
        private Button saveDepositButton;
        private TextBox depositTextBox;
    }
}
