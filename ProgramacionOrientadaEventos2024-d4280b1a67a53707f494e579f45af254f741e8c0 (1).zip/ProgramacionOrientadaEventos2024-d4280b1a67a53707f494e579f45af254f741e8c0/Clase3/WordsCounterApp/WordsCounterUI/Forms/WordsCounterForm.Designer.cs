﻿namespace WordsCounterUI.Forms
{
    partial class WordsCounterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            wordsCounterTextBox = new TextBox();
            resultLabel = new Label();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(245, 38);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(296, 38);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Contador de Palabras";
            // 
            // wordsCounterTextBox
            // 
            wordsCounterTextBox.BorderStyle = BorderStyle.FixedSingle;
            wordsCounterTextBox.Location = new Point(86, 112);
            wordsCounterTextBox.Multiline = true;
            wordsCounterTextBox.Name = "wordsCounterTextBox";
            wordsCounterTextBox.Size = new Size(649, 192);
            wordsCounterTextBox.TabIndex = 1;
            wordsCounterTextBox.KeyDown += wordsCounterTextBox_KeyDown;
            wordsCounterTextBox.KeyPress += wordsCounterTextBox_KeyPress;
            wordsCounterTextBox.KeyUp += wordsCounterTextBox_KeyUp;
            // 
            // resultLabel
            // 
            resultLabel.AutoSize = true;
            resultLabel.Location = new Point(95, 363);
            resultLabel.Name = "resultLabel";
            resultLabel.Size = new Size(0, 38);
            resultLabel.TabIndex = 2;
            // 
            // WordsCounterForm
            // 
            AutoScaleDimensions = new SizeF(16F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(824, 510);
            Controls.Add(resultLabel);
            Controls.Add(wordsCounterTextBox);
            Controls.Add(titleLabel);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(6);
            Name = "WordsCounterForm";
            Text = "WordsCounterForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private TextBox wordsCounterTextBox;
        private Label resultLabel;
    }
}