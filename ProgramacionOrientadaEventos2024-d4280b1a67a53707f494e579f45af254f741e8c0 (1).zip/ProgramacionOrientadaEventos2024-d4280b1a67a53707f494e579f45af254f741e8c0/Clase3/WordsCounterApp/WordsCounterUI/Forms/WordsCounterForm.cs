﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordsCounterUI.Forms
{
    public partial class WordsCounterForm : Form
    {
        public WordsCounterForm()
        {
            InitializeComponent();
        }

        private void wordsCounterTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            //int counterWords = wordsCounterTextBox.Text.Trim().Split(" ").Length;

            //resultLabel.Text = $"La cantidad de palabras ingresadas es {counterWords}";
        }

        private void wordsCounterTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            //int counterWords = wordsCounterTextBox.Text.Trim().Split(" ").Length;

            //resultLabel.Text = $"La cantidad de palabras ingresadas es {counterWords}";
        }

        private void wordsCounterTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            int counterWords = wordsCounterTextBox.Text.Trim().Split(" ").Length;

            resultLabel.Text = $"La cantidad de palabras ingresadas es {counterWords}";
        }
    }
}
