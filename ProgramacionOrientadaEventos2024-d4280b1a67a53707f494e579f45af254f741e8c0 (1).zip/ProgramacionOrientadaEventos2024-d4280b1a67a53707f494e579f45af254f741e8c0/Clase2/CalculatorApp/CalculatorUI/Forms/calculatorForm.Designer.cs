﻿namespace CalculatorUI
{
    partial class calculatorForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLabel = new Label();
            firstNumberLabel = new Label();
            firstNumberTextBox = new TextBox();
            secondNumberTextBox = new TextBox();
            secondNumberLabel = new Label();
            calculateSumButton = new Button();
            resultLabel = new Label();
            SuspendLayout();
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleLabel.Location = new Point(260, 38);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(170, 38);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Calculadora";
            // 
            // firstNumberLabel
            // 
            firstNumberLabel.AutoSize = true;
            firstNumberLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            firstNumberLabel.Location = new Point(79, 127);
            firstNumberLabel.Name = "firstNumberLabel";
            firstNumberLabel.Size = new Size(229, 38);
            firstNumberLabel.TabIndex = 1;
            firstNumberLabel.Text = "Primer Numero ";
            // 
            // firstNumberTextBox
            // 
            firstNumberTextBox.BorderStyle = BorderStyle.FixedSingle;
            firstNumberTextBox.Location = new Point(327, 136);
            firstNumberTextBox.Name = "firstNumberTextBox";
            firstNumberTextBox.Size = new Size(298, 27);
            firstNumberTextBox.TabIndex = 2;
            // 
            // secondNumberTextBox
            // 
            secondNumberTextBox.BorderStyle = BorderStyle.FixedSingle;
            secondNumberTextBox.Location = new Point(327, 222);
            secondNumberTextBox.Name = "secondNumberTextBox";
            secondNumberTextBox.Size = new Size(298, 27);
            secondNumberTextBox.TabIndex = 4;
            // 
            // secondNumberLabel
            // 
            secondNumberLabel.AutoSize = true;
            secondNumberLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            secondNumberLabel.Location = new Point(79, 213);
            secondNumberLabel.Name = "secondNumberLabel";
            secondNumberLabel.Size = new Size(257, 38);
            secondNumberLabel.TabIndex = 3;
            secondNumberLabel.Text = "Segundo Numero ";
            // 
            // calculateSumButton
            // 
            calculateSumButton.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calculateSumButton.Location = new Point(265, 316);
            calculateSumButton.Name = "calculateSumButton";
            calculateSumButton.Size = new Size(137, 49);
            calculateSumButton.TabIndex = 5;
            calculateSumButton.Text = "Sumar";
            calculateSumButton.UseVisualStyleBackColor = true;
            calculateSumButton.Click += calculateSumButton_Click;
            // 
            // resultLabel
            // 
            resultLabel.AutoSize = true;
            resultLabel.Location = new Point(88, 398);
            resultLabel.Name = "resultLabel";
            resultLabel.Size = new Size(0, 20);
            resultLabel.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(resultLabel);
            Controls.Add(calculateSumButton);
            Controls.Add(secondNumberTextBox);
            Controls.Add(secondNumberLabel);
            Controls.Add(firstNumberTextBox);
            Controls.Add(firstNumberLabel);
            Controls.Add(titleLabel);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLabel;
        private Label firstNumberLabel;
        private TextBox firstNumberTextBox;
        private TextBox secondNumberTextBox;
        private Label secondNumberLabel;
        private Button calculateSumButton;
        private Label resultLabel;
    }
}
