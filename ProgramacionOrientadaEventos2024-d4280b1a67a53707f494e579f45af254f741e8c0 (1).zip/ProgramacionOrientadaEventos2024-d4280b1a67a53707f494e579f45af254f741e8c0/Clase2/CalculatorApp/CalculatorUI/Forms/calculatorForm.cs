namespace CalculatorUI
{
    public partial class calculatorForm : Form
    {
        public calculatorForm()
        {
            InitializeComponent();
        }

        private void calculateSumButton_Click(object sender, EventArgs e)
        {
            int firstNumber = Convert.ToInt32(firstNumberTextBox.Text);
            int secondNumber = Convert.ToInt32(secondNumberTextBox.Text);

            int result = firstNumber + secondNumber;

            resultLabel.Text = $"El sumatoria de {firstNumber} + {secondNumber} = {result}";
        }
    }
}
