# Programación Orientada a Eventos Ciclo II 2024

## Lenguajes de Programación

- C#
- SQL

## Herramientas a usar

- Visual Studio
- SQL Server

## Grupo Telegram

Link: [Grupo](https://t.me/+-sw1zAoa2ONkMzJh)


