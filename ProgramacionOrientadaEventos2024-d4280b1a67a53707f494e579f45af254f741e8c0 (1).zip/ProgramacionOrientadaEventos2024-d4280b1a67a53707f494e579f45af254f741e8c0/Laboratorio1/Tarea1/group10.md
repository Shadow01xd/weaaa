# Integrantes

- Roberto Carlos Contreras Argueta u20210852
- Oscar Isaí Vasquez Vigil u20230215
- Jefferson Darwin Santos Hernandez u20170092

# Ejercicios a desarrollar

1. Crear un programa que permita ingresar 3 números. Determinar cuál es el menor de los 3. Use eventos de mouse.

2. Colocar en mayúscula la primera letra de cada palabra ingresada por el usuario.

3. Crear un programa que ayude a calcular el área y perímetro de un triángulo y un pentágono. Para resolver el ejercicio debe usar clases y objetos.

4. Crear un programa que no permita usar las teclas ***i, j, k, l*** al usuario, cada vez que se presione una de las teclas mencionadas mandar un mensaje de adventencia al usuario que están prohibidas.

5. Crear un programa que permita convertir la edad de una persona de años en días

6. Crear un programa que permita convertir de millas a kilómetros y viceversa. Debe usar POO.

# Criterios de Evaluación

- El programa debe realizar correctamente lo que se indicó en el ejercicio.
- El código debe ser un código ordenado y con buenas prácticas.
- Se evaluará el uso correcto de los distintos eventos como: eventos de mouse, click, etc.
- Debe tener validaciones y excepciones para asegurarse que funcione correctamente.
- Se evaluará puntualidad en la entrega. Si se entrega después del tiempo estimulado recibirá una sanción de puntos menos en su calificación.
- Agregar un archivo de texto con los nombres completos de los integrantes del grupo y su carnet de estudiante.
- Dentro del archivo de texto agregar el enlace del repositorio de GitHub
- Cada integrante del grupo debe realizar los respectivos commits del ejercicio que realizaron como prueba del trabajo realizado
- El **README** del repositorio debe reflejar la división de ejercicios por estudiante
- La tarea se subirá al ***campus virtual*** en formato **ZIP**
- Fecha de Entrega **16/08/2024**
