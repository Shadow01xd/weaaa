# Integrantes

- Anderson Amilcar Fuentes Portillo u20230098
- Orlando Bladimir Zúñiga Hernández u20230405
- Marilyn Michelle Jiménez Arias u20231085

# Ejercicios a desarrollar

1. Crear un programa que acepte dos string ingresados por el usuario y determinar si son iguales.

2. Crear un formulario que permita calcular el tangente en grados y en radianes. Debe usar eventos de mouse para resolver el ejercicio.

3. Crear un programa que ayude a calcular el área y perímetro de un romboide y un trapezoide. Para resolver el ejercicio debe usar clases y objetos.

4. Crear un programa que permita determinar si la tecla que presionó el usuario es ***flecha de dirección***. Deberán mostrar un mensaje al usuario solamente en caso de que se presione **una flecha de dirección** y mostrar el mensaje: "Se presiono la tecla x". Donde "x" representa la tecla que presiono el usuario, para mostrar el mensaje puede hacerlo con un ***MessageBox*** o un ***Label***

5. Crear un programa que permita calcular el factorial de un número de forma recursiva

6. Crear un programa que permita calcular aceleración en función de la velocidad y el tiempo . Use POO.

# Criterios de Evaluación

- El programa debe realizar correctamente lo que se indicó en el ejercicio.
- El código debe ser un código ordenado y con buenas prácticas.
- Se evaluará el uso correcto de los distintos eventos como: eventos de mouse, click, etc.
- Debe tener validaciones y excepciones para asegurarse que funcione correctamente.
- Se evaluará puntualidad en la entrega. Si se entrega después del tiempo estimulado recibirá una sanción de puntos menos en su calificación.
- Agregar un archivo de texto con los nombres completos de los integrantes del grupo y su carnet de estudiante.
- Dentro del archivo de texto agregar el enlace del repositorio de GitHub
- Cada integrante del grupo debe realizar los respectivos commits del ejercicio que realizaron como prueba del trabajo realizado
- El **README** del repositorio debe reflejar la división de ejercicios por estudiante
- La tarea se subirá al ***campus virtual*** en formato **ZIP**
- Fecha de Entrega **16/08/2024**
