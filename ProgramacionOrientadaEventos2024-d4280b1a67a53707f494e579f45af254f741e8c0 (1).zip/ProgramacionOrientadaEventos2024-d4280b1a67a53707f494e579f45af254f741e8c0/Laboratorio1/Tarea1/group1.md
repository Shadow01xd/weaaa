# Integrantes

1. Gustavo Emanuel Rivas Avalos u20230321
2. Merlyn Nicole Rajo Reyes u20230976
3. Dalia Melissa Araujo Rivas u20230620

# Ejercicios a desarrollar

1. Crear un programa que permita determinar si la tecla que presionó el usuario es un número. Deberán mostrar un mensaje al usuario solamente en caso de que se digite un número y el mensaje debe contener lo siguiente: "Se presionó el número x". En este caso "x" representa la tecla ingresada por el usuario, para el mensaje puede mostrarlo en un ***MessageBox*** o en un ***Label***. Debe usar eventos de tecla.

2. Crear un formulario que permita al usuario ingresar una frase, el programa deberá determinar si la frase ingresada es un ***palíndromo***.

3. Crea un programa que calcule cuántas cifras tiene un número entero positivo.

4. Crear un formulario que determine si dos strings son iguales, debe usar eventos de ***mouse***.

5. Crear un programa que ayude a calcular el área y perímetro de un trapecio y un pentágono. Para resolver el ejercicio debe usar clases y objetos.

6. Crear un programa que permita calcular el interés simple. Use POO.

# Criterios de Evaluación

- El programa debe realizar correctamente lo que se indicó en el ejercicio.
- El código debe ser un código ordenado y con buenas prácticas.
- Se evaluará el uso correcto de los distintos eventos como: eventos de mouse, click, etc.
- Debe tener validaciones y excepciones para asegurarse que funcione correctamente.
- Se evaluará puntualidad en la entrega. Si se entrega después del tiempo estimulado recibirá una sanción de puntos menos en su calificación.
- Agregar un archivo de texto con los nombres completos de los integrantes del grupo y su carnet de estudiante.
- Dentro del archivo de texto agregar el enlace del repositorio de GitHub
- Cada integrante del grupo debe realizar los respectivos commits del ejercicio que realizaron como prueba del trabajo realizado
- El **README** del repositorio debe reflejar la división de ejercicios por estudiante
- La tarea se subirá al ***campus virtual*** en formato **ZIP**  
- Fecha de entrega: **16/08/2024**
