# Integrantes

- René Alejandro Vásquez Ochoa u20230402
- Aristides Alfonso Fuentes Cañas u20230349
- Jeferson Bladimir Trejos Lovo u20230271

# Ejercicios a desarrollar

1. Crear un programa que acepte dos string y determinar si son un anagrama

2. Crear un formulario que permita calcular el coseno en grados y en radianes. Debe usar eventos de mouse para resolver el ejercicio.

3. Crear un programa que ayude a calcular el área y perímetro de un cuadrado y una circunferencia. Para resolver el ejercicio debe usar clases y objetos.

4. Crear un programa que permita determinar si la tecla que presionó el usuario es ***Barra Espaciadora***. Deberán mostrar un mensaje al usuario solamente en caso de que se presione **Barra Espaciadora** y mostrar el mensaje: "Cuidado. No se permite presionar la Barra Espaciadora". No debe permitir ingresar espacios. Para el mensaje puede mostrarlo en un ***MessageBox*** o en un ***Label***. Debe usar eventos de tecla.

5. Crear un programa que permita calcular el área de un triángulo ingresando sus tres lados. Debe usar la fórmula de Herón para realizar el cálculo. Fórmula de Herón [https://es.wikipedia.org/wiki/F%C3%B3rmula_de_Her%C3%B3n](Fórmula de Herón)

6. Crear un programa que permita calcular aceleración en función de la velocidad y el tiempo . Use POO.

# Criterios de Evaluación

- El programa debe realizar correctamente lo que se indicó en el ejercicio.
- El código debe ser un código ordenado y con buenas prácticas.
- Se evaluará el uso correcto de los distintos eventos como: eventos de mouse, click, etc.
- Debe tener validaciones y excepciones para asegurarse que funcione correctamente.
- Se evaluará puntualidad en la entrega. Si se entrega después del tiempo estimulado recibirá una sanción de puntos menos en su calificación.
- Agregar un archivo de texto con los nombres completos de los integrantes del grupo y su carnet de estudiante.
- Dentro del archivo de texto agregar el enlace del repositorio de GitHub
- Cada integrante del grupo debe realizar los respectivos commits del ejercicio que realizaron como prueba del trabajo realizado
- El **README** del repositorio debe reflejar la división de ejercicios por estudiante
- La tarea se subirá al ***campus virtual*** en formato **ZIP**
- Fecha de entrega **16/08/2024** 
